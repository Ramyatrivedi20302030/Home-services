
<?php
class UserController {
    public function login() {
        echo "Login Logic Here";
    }
}
?>
