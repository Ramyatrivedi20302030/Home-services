
<?php
require_once '../config/config.php';
echo "<h1>HomeServicePro SaaS Platform</h1>";
echo "<p>Production Ready Version</p>";
?>
